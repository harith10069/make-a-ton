---
name: Executive Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464f'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#767680'
  outline-variant: '#c6c5d0'
  surface-tint: '#4f5c8e'
  primary: '#000f3f'
  on-primary: '#ffffff'
  primary-container: '#172554'
  on-primary-container: '#808dc2'
  inverse-primary: '#b7c4fd'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00142c'
  on-tertiary: '#ffffff'
  tertiary-container: '#00294f'
  on-tertiary-container: '#4a92e5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4fd'
  on-primary-fixed: '#071747'
  on-primary-fixed-variant: '#374475'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  metric-val:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-xs:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system targets enterprise finance leaders, RevOps managers, and procurement specialists handling high-volume recurring revenue, billing lifecycles, and subscription analytics. The aesthetic pairs structural modernism with high-density enterprise utility. It must evoke trust, financial clarity, rigorous control, and seamless velocity.

The style operates at the intersection of **Corporate Modern** and **Precision SaaS**:
- Utilitarian data density balanced with generous structural breathing room.
- Micro-deliberate details: razor-thin dividers, disciplined hierarchy, and functional status markers over decorative graphics.
- Frictionless workflow support: dense, low-noise interfaces engineered for sustained daily operation without visual exhaustion.

## Colors
The color architecture reinforces trust and operational precision through a disciplined blue-and-slate scale:

- **Primary Anchor (`#172554` - Deep Navy):** Represents foundational institutional authority. Reserved for primary brand touchpoints, top-level navigation shells, active sidebars, and critical CTA surfaces.
- **Action Driver (`#2563EB` - Primary Blue):** Governs primary user interactions, interactive states, selected navigation markers, and focus states.
- **Accent & Inflection (`#60A5FA` - Sky Blue):** Applied sparingly for hover glow states, progress tracks, active chart series, and contextual information highlights.
- **Canvases & Surfaces:** Canvas base is `#F8FAFC` (Slate 50), providing soft separation against elevated cards and floating surfaces styled in pure `#FFFFFF`.
- **Text Tiers:**
  - High-emphasis primary body and headlines: `#172033` (Slate 900 variant for crisp legibility without harsh black clipping).
  - Mid-emphasis secondary text, metadata, and column headers: `#64748B` (Slate 500).
  - Low-emphasis placeholders and disabled states: `#94A3B8` (Slate 400).
- **Structural Outlines:** `#E2E8F0` (Slate 200) defines clean borders across cards, table rows, and form components.
- **System States:**
  - **Success (`#16A34A`):** Active subscriptions, successful settlements, positive growth deltas.
  - **Warning (`#F59E0B`):** Impending card expiries, churn alerts, review required.
  - **Danger (`#DC2626`):** Past-due invoices, churned accounts, payment gateway errors.

## Typography
Built around `Inter` to provide neutral, systematic clarity across dense tabular grids, numerical dashboards, and complex administrative views.

- **Tabular Figures:** Always apply `font-feature-settings: "tnum" 1` to metrics, financial totals, table rows, and dates to preserve vertical column alignment.
- **Hierarchy:** Primary display levels prioritize negative tracking (`letter-spacing: -0.02em` to `-0.03em`) to tighten headings and prevent excessive visual sprawl.
- **Labels & Micro-copy:** Badges, column headers, and KPI descriptors use `label-xs` and `label-sm` with subtle positive tracking for immediate legibility at small sizes.

## Layout & Spacing
The layout model employs a fluid 12-column grid anchored by a standard desktop workspace maximum width of 1440px with sticky or collapsible navigation shells.

- **Desktop (>= 1280px):** 12 columns, 24px (`1.5rem`) gutter, 32px (`2rem`) canvas margins. Navigation panel defaults to fixed 260px width.
- **Tablet (768px - 1279px):** 8 columns, 16px (`1rem`) gutter, 24px (`1.5rem`) canvas margins. Navigation rail collapses to a 72px icon bar.
- **Mobile (< 768px):** 4 columns, 16px (`1rem`) gutter, 16px (`1rem`) canvas margins. Navigation moves to a responsive off-canvas drawer or sticky header bar.
- **Spacing Rhythm:** Form and card padding follow an 8-point system scaled with half-steps (`4px`, `8px`, `12px`, `16px`, `24px`, `32px`). Element spacing inside metric groups strictly uses `space-xs` and `space-sm` to maintain analytical cohesion.

## Elevation & Depth
Elevation is realized through the interplay of crisp 1px borders (`#E2E8F0`) and diffused, low-opacity ambient shadows tinted with deep slate (`rgba(15, 23, 42, ...)`). Surface nesting creates spatial order:

- **Level 0 (Canvas):** `#F8FAFC` flat surface.
- **Level 1 (Default Containers & Cards):** `#FFFFFF` surface with a continuous 1px outline (`#E2E8F0`) and micro-shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.05)`.
- **Level 2 (Hovered Cards & Dropdowns):** `#FFFFFF` surface with border `#CBD5E1` and lifted shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Level 3 (Modal Sheets & Flyouts):** `#FFFFFF` surface accompanied by a structural border and floating depth: `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)`. Modals pair with a softened backdrop tint: `rgba(15, 23, 42, 0.4)`.

## Shapes
The structural language balances modern softness with enterprise precision:
- Primary container cards and metric dashboards utilize `rounded-xl` (`1.5rem` / `24px` outer radius or `1rem` / `16px` inner radius) to present a modern, refined frame.
- Interactive controls (buttons, inputs, select fields, tabs) adhere to `0.5rem` (`8px`) roundedness to maintain crisp alignment with adjacent data grids.
- Status badges and metadata tags maintain fully rounded pill profiles (`9999px`) for quick scanning.

## Components

### Buttons
- **Primary:** Background `#172554`, label text `#FFFFFF`, border none, micro-elevation shadow. On hover, background shifts to `#1E3A8A`. On active focus, a 2px offset ring in `#2563EB` appears.
- **Secondary / Standard:** Background `#FFFFFF`, border 1px solid `#E2E8F0`, label text `#172033`. On hover, background transitions to `#F8FAFC` and border transitions to `#CBD5E1`.
- **Accent:** Background `#2563EB`, label text `#FFFFFF`. Hover: `#1D4ED8`.
- **Ghost:** Background transparent, text `#64748B`. Hover: `#F1F5F9`, text `#172033`.
- **Height & Spacing:** Standard inputs/buttons are 40px tall (compact 36px in data tables), horizontal padding 16px, icon sizing 16px with an 8px label gap.

### Status Badges & Chips
- Fully rounded pills with balanced padding (4px vertical, 10px horizontal) and `label-xs` typography.
- Status styles:
  - **Active / Paid:** Background `#DCFCE7`, text `#15803D`, border 1px solid `#BBF7D0`.
  - **Trialing / Pending:** Background `#FEF3C7`, text `#B45309`, border 1px solid `#FDE68A`.
  - **Past Due / Canceled:** Background `#FEE2E2`, text `#B91C1C`, border 1px solid `#FECACA`.
  - **Draft / Inactive:** Background `#F1F5F9`, text `#475569`, border 1px solid `#E2E8F0`.
- Badges incorporate an optional 6px circular dot on the leading edge for immediate status scanning.

### Input Fields & Controls
- **Inputs:** Height 40px, background `#FFFFFF`, border 1px solid `#E2E8F0`, border-radius 8px, text `#172033`, placeholder `#94A3B8`. Focus state applies border `#2563EB` and a box-shadow ring of `0 0 0 3px rgba(37, 99, 235, 0.15)`.
- **Checkboxes & Radios:** 16px width/height, border 1.5px solid `#CBD5E1`. Checked state fills `#2563EB` with `#FFFFFF` iconography.

### Metrics Cards
- Standard layout: Card container (`#FFFFFF`, 1px solid `#E2E8F0`, rounded-xl, padding 20px).
- Top row: Metric label (`label-sm`, `#64748B`) aligned with a subtle 32px rounded-lg icon container (`#F1F5F9` background, `#2563EB` Lucide icon).
- Middle row: Value formatted in `metric-val` (`#172033`), tabular figures.
- Bottom row: Inline delta indicator (e.g., `+12.4% vs last month`) accompanied by an up/down trend arrow in `#16A34A` or `#DC2626`.

### Data Tables with Pagination
- **Header:** Background `#F8FAFC`, height 40px, text `label-xs` uppercase `#64748B`, border-bottom 1px solid `#E2E8F0`.
- **Row:** Height 52px, background `#FFFFFF`, hover background `#F8FAFC`, border-bottom 1px solid `#F1F5F9`.
- **Numeric Alignment:** Right-align all currency, MRR/ARR, quantity, and date columns.
- **Pagination Footer:** Height 56px, flex row with "Showing X-Y of Z entries", page size selector, and discrete pagination controls (previous/next chevron buttons, numbered pill tabs).

### Modern Segmented Tabs
- Container uses `#F1F5F9` background with 6px padding and 8px border-radius.
- Tab triggers: Height 32px, text `label-sm`, padding 0 12px, border-radius 6px.
- Selected tab: Pure `#FFFFFF` background, text `#172033`, elevation `0 1px 3px rgba(15, 23, 42, 0.08)`.

### Modal Sheets & Drawers
- Used for subscription provisioning, invoice inspection, and plan editing.
- Slide-over sheet pinned to the right edge: Width 480px or 640px, height 100vh, background `#FFFFFF`, border-left 1px solid `#E2E8F0`, Level 3 elevation.
- Header includes title, status badge, and close button; body scrolls independently; footer remains sticky with dual primary/secondary action buttons.

### Iconography Rules
- Lucide-style outline icons with a unified 1.5px or 1.75px stroke width.
- Sizing standard: 16px for interactive controls/badges, 20px for navigation and table actions, 24px for top-level empty states.